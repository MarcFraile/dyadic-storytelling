# ELECTRA Field Study

This repo contains the processed recordings for the school study performed by Marc Fraile, Natalia Calvo and Anastasia Akkuzzu during VT23 in Uppsala. It also contains scripts to process this data for feature extraction, etc.

It pre-supposes the presence of OpenFace and OpenPose binaries in specific locations.
