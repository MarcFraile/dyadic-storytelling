# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['local']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=10.0.0,<11.0.0',
 'imageio[pyav]>=2.31.2,<3.0.0',
 'ipympl>=0.9.3,<0.10.0',
 'matplotlib>=3.8.0,<4.0.0',
 'mff-pretty-cli>=0.1.0,<0.2.0',
 'notebook>=7.0.3,<8.0.0',
 'numpy>=1.25.2,<2.0.0',
 'pandas>=2.1.0,<3.0.0',
 'py-feat>=0.6.1,<0.7.0',
 'pyrr>=0.10.3,<0.11.0',
 'scikit-learn>=1.3.0,<2.0.0',
 'tqdm>=4.66.1,<5.0.0']

setup_kwargs = {
    'name': '2023-electra-field-marcschoolstudy',
    'version': '0.1.0',
    'description': '',
    'long_description': '# ELECTRA Field Study\n\nThis repo contains the processed recordings for the school study performed by Marc Fraile, Natalia Calvo and Anastasia Akkuzzu during VT23 in Uppsala. It also contains scripts to process this data for feature extraction, etc.\n\nIt pre-supposes the presence of OpenFace and OpenPose binaries in specific locations.\n',
    'author': 'Marc Fraile',
    'author_email': 'marc.fraile.fabrega@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
